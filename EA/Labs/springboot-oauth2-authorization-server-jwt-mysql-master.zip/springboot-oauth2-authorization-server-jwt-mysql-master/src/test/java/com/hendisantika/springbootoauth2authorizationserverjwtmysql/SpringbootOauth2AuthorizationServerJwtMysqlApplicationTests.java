package com.hendisantika.springbootoauth2authorizationserverjwtmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootOauth2AuthorizationServerJwtMysqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
