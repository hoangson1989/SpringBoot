package willydekeyser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOauth2ClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
