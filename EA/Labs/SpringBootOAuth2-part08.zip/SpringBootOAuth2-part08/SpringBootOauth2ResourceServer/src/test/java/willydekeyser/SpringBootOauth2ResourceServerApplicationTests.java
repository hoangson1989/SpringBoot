package willydekeyser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOauth2ResourceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
